package com.progettodogsitting.dogsitting_backend.model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.EqualsAndHashCode;
import java.util.List;

// Annotazione Lombok per getter, setter ecc.
@Data
// Include i campi della superclasse nel calcolo di equals/hashCode
@EqualsAndHashCode(callSuper = true)
// Indica che questa è un'entità JPA
@Entity
// Mappa questa classe sulla tabella "DOG_SITTER"
@Table(name = "DOG_SITTER")
// Definisce la colonna "username" come foreign key verso la tabella padre Utente
@PrimaryKeyJoinColumn(name = "USERNAME_D")
public class Dogsitter extends Utente {

    // Specifica il limite massimo di cani che il dogsitter può gestire
    @Column(name = "MAX_CANI", nullable = false)
    private Integer maxCani;

    // Indica che si tratta di una collezione di elementi stringa associati a questo dogsitter
    // @ElementCollection usa FetchType.LAZY per default, quindi quando fai findAll() JPA non fetcha subito le collezioni. Le carica solo quando le accedi nel codice:
    @ElementCollection
    // Definisce la tabella di join "giorni_dog_sitter" e la sua chiave esterna "username"
    // name in @JoinColumn specifica solo il nome della colonna nella tabella figlia. Il dove punta lo deduce 
    // dal contesto — cioè dalla classe in cui si trova il codice.
    // Tu stai scrivendo quel codice dentro Dogsitter, quindi JPA sa già che la tabella di riferimento è 
    // dog_sitter e che la sua PK è username.
    @CollectionTable(name = "GIORNI_DOG_SITTER", joinColumns = @JoinColumn(name = "USERNAME_D"))
    // Nome della colonna in cui verranno salvati i giorni all'interno della collection table
    @Column(name = "GIORNO_DISPONIBILE")
    private List<String> giorniDisponibili;

    // Collezione di elementi per definire le taglie dei cani gestibili
    @ElementCollection
    // Tabella esterna "TAGLIE_CANI" collegata all'username del dogsitter
    @CollectionTable(name = "TAGLIE_CANI", joinColumns = @JoinColumn(name = "USERNAME_D"))
    // Colonna contenente la stringa della taglia (es: grande, piccola)
    @Column(name = "TAGLIA")
    private List<String> taglieCani;
}
