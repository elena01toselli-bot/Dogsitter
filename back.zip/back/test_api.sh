#!/bin/bash

# Test Script for API Endpoints

echo "🚀 Inizio dei test API..."

# 1. Test Registrazione Cliente
echo -n "1. Registrazione Cliente: "
RESPONSE=$(curl -s -X POST http://localhost:8080/api/utenti/create \
    -H "Content-Type: application/json" \
    -d '{
        "username": "test.cliente.bash",
        "password": "password123",
        "ruolo": "cliente",
        "nomeBattesimo": "Mario",
        "cognome": "Rossi",
        "cap": "00100",
        "nCivico": "1",
        "provincia": "RM",
        "via": "Via Roma",
        "nTel": "3331234567"
    }')
TOKEN=$(echo "$RESPONSE" | grep -o '"token":"[^"]*' | cut -d'"' -f4)
if [ -n "$TOKEN" ]; then
    echo "✅ PASS (Token ricevuto)"
else
    echo "❌ FAIL ($RESPONSE)"
    exit 1
fi

# 2. Test Login Cliente
echo -n "2. Login Cliente: "
RESPONSE=$(curl -s -X POST http://localhost:8080/api/utenti/login \
    -H "Content-Type: application/json" \
    -d '{
        "username": "test.cliente.bash",
        "password": "password123",
        "ruolo": "cliente"
    }')
if echo "$RESPONSE" | grep -q '"token"'; then
    echo "✅ PASS (Login effettuato)"
else
    echo "❌ FAIL ($RESPONSE)"
fi

# 3. Test Registrazione Cane (Richiede Auth)
echo -n "3. Registrazione Cane: "
STATUS_CODE=$(curl -s -o /dev/null -w "%{http_code}" -X POST http://localhost:8080/api/cani \
    -H "Content-Type: application/json" \
    -H "Authorization: Bearer $TOKEN" \
    -d '{
        "nMicrochip": "111111111111111",
        "nome": "Fido",
        "razza": "Labrador",
        "taglia": "Grande",
        "dataNascita": "2020-05-10",
        "usernameCliente": "test.cliente.bash"
    }')
if [ "$STATUS_CODE" -eq 204 ] || [ "$STATUS_CODE" -eq 200 ]; then
    echo "✅ PASS (Cane registrato, status $STATUS_CODE)"
else
    echo "❌ FAIL (Status $STATUS_CODE)"
fi

# 4. Test Lettura Cani Cliente (Richiede Auth)
echo -n "4. Lettura Cani del Cliente: "
RESPONSE=$(curl -s -X GET http://localhost:8080/api/cani/cliente/test.cliente.bash \
    -H "Authorization: Bearer $TOKEN")
if echo "$RESPONSE" | grep -q '"nome":"Fido"'; then
    echo "✅ PASS (Cane trovato)"
else
    echo "❌ FAIL ($RESPONSE)"
fi

# 5. Test Lettura Lista Dogsitter (Richiede Auth)
echo -n "5. Lettura Dogsitter List: "
STATUS_CODE=$(curl -s -o /dev/null -w "%{http_code}" -X GET http://localhost:8080/api/dogsitter \
    -H "Authorization: Bearer $TOKEN")
if [ "$STATUS_CODE" -eq 200 ]; then
    echo "✅ PASS (Lista Dogsitter recuperata)"
else
    echo "❌ FAIL (Status $STATUS_CODE)"
fi

echo "🎉 Test Completati!"
