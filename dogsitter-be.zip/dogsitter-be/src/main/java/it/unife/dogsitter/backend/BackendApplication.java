package it.unife.dogsitter.backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Classe principale dell'applicazione Spring Boot Dogsitter.
 * Il punto di ingresso dell'app: avvia il contesto Spring e tutti i bean.
 */
@SpringBootApplication
public class BackendApplication {

    /**
     * Metodo main: lancia l'applicazione Spring Boot.
     *
     * @param args argomenti da riga di comando (non utilizzati)
     */
    public static void main(String[] args) {
        SpringApplication.run(BackendApplication.class, args);
    }
}
