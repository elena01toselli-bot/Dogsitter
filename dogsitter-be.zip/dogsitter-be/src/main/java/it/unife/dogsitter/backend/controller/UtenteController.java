package it.unife.dogsitter.backend.controller;

import it.unife.dogsitter.backend.model.Utente;
import it.unife.dogsitter.backend.service.UtenteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * Controller REST per la gestione degli Utenti e dell'autenticazione.
 *
 * Espone gli endpoint:
 *   POST   /api/auth/login        → login utente
 *   GET    /api/utenti            → lista tutti gli utenti (+ ?username= per filtro)
 *   GET    /api/utenti/{username} → dettaglio utente
 *   POST   /api/utenti            → registrazione nuovo utente
 *   PUT    /api/utenti/{username} → aggiornamento utente
 *   DELETE /api/utenti/{username} → cancellazione utente
 */
@RestController
@CrossOrigin(origins = "*")
public class UtenteController {

    @Autowired
    private UtenteService service;

    /**
     * Endpoint di login: riceve username e password, verifica le credenziali
     * e restituisce un token mock + i dati minimi dell'utente (username, ruolo).
     *
     * POST /api/auth/login
     * Body: { "username": "...", "password": "..." }
     *
     * @param body mappa con le chiavi "username" e "password"
     * @return 200 con token e dati utente, oppure 401 se le credenziali sono errate
     */
    @PostMapping("/api/auth/login")
    public ResponseEntity<?> login(@RequestBody Map<String, String> body) {
        String username = body.get("username");
        String password = body.get("password");
        Optional<Utente> utente = service.login(username, password);
        if (utente.isPresent()) {
            // Risposta compatibile con il frontend: token + oggetto user minimale
            return ResponseEntity.ok(Map.of(
                "token", "token-" + username,
                "user", Map.of("username", utente.get().getUsername(),
                               "ruolo",    utente.get().getRuolo())
            ));
        }
        return ResponseEntity.status(401).body("Credenziali errate");
    }

    /**
     * Restituisce tutti gli utenti o filtra per username se il parametro è presente.
     * Supporta sia GET /api/utenti che GET /api/utenti?username=mario.
     *
     * GET /api/utenti
     * GET /api/utenti?username={username}
     *
     * @param username parametro opzionale per il filtro
     * @return lista di utenti
     */
    @GetMapping("/api/utenti")
    public List<Utente> getAll(@RequestParam(required = false) String username) {
        if (username != null) {
            // Il frontend usa questa forma come fallback per recuperare un singolo utente
            return service.findAllByUsername(username);
        }
        return service.findAll();
    }

    /**
     * Restituisce un singolo utente tramite il suo username.
     *
     * GET /api/utenti/{username}
     *
     * @param username lo username dell'utente da cercare
     * @return 200 con l'utente, oppure 404 se non esiste
     */
    @GetMapping("/api/utenti/{username}")
    public ResponseEntity<Utente> getById(@PathVariable String username) {
        Optional<Utente> utente = service.findById(username);
        return utente.map(ResponseEntity::ok)
                     .orElseGet(() -> ResponseEntity.notFound().build());
    }

    /**
     * Registra un nuovo utente (cliente o dogsitter).
     *
     * POST /api/utenti
     * Body: oggetto Utente
     *
     * @param utente i dati dell'utente da registrare
     * @return l'utente creato
     */
    @PostMapping("/api/utenti")
    public Utente create(@RequestBody Utente utente) {
        return service.save(utente);
    }

    /**
     * Aggiorna i dati di un utente esistente.
     * Verifica che l'utente esista prima di aggiornarlo.
     *
     * PUT /api/utenti/{username}
     * Body: oggetto Utente aggiornato
     *
     * @param username lo username dell'utente da aggiornare
     * @param utente   i nuovi dati dell'utente
     * @return 200 con l'utente aggiornato, oppure 404 se non esiste
     */
    @PutMapping("/api/utenti/{username}")
    public ResponseEntity<Utente> update(@PathVariable String username,
                                         @RequestBody Utente utente) {
        if (!service.findById(username).isPresent()) {
            return ResponseEntity.notFound().build();
        }
        utente.setUsername(username);
        return ResponseEntity.ok(service.save(utente));
    }

    /**
     * Elimina un utente tramite il suo username.
     *
     * DELETE /api/utenti/{username}
     *
     * @param username lo username dell'utente da eliminare
     * @return 204 No Content se eliminato, oppure 404 se non esiste
     */
    @DeleteMapping("/api/utenti/{username}")
    public ResponseEntity<Void> delete(@PathVariable String username) {
        if (!service.findById(username).isPresent()) {
            return ResponseEntity.notFound().build();
        }
        service.deleteById(username);
        return ResponseEntity.noContent().build();
    }
}
