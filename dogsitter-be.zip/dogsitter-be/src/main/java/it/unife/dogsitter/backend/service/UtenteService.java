package it.unife.dogsitter.backend.service;

import it.unife.dogsitter.backend.model.Utente;
import it.unife.dogsitter.backend.repository.UtenteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

/**
 * Service per la gestione degli Utenti.
 * Contiene la logica di business per registrazione, login, ricerca,
 * aggiornamento e cancellazione utenti.
 */
@Service
public class UtenteService {

    @Autowired
    private UtenteRepository repository;

    /** Restituisce tutti gli utenti presenti nel database. */
    public List<Utente> findAll() {
        return repository.findAll();
    }

    /**
     * Cerca un utente tramite il suo username (chiave primaria).
     * @param username la chiave primaria
     * @return Optional con l'utente o vuoto se non trovato
     */
    public Optional<Utente> findById(String username) {
        return repository.findById(username);
    }

    /**
     * Salva un nuovo utente o aggiorna uno esistente.
     * @param utente l'utente da persistere
     * @return l'utente salvato
     */
    public Utente save(Utente utente) {
        return repository.save(utente);
    }

    /**
     * Elimina un utente dal database tramite lo username.
     * @param username lo username dell'utente da eliminare
     */
    public void deleteById(String username) {
        repository.deleteById(username);
    }

    /**
     * Verifica le credenziali di login.
     * @param username lo username inserito
     * @param password la password inserita
     * @return Optional con l'utente se autenticato, vuoto se le credenziali sono errate
     */
    public Optional<Utente> login(String username, String password) {
        return repository.findByUsernameAndPassword(username, password);
    }

    /**
     * Cerca utenti per username — usato dal frontend come fallback di ricerca.
     * @param username lo username da filtrare
     * @return lista di utenti con quel username (di norma 0 o 1)
     */
    public List<Utente> findAllByUsername(String username) {
        return repository.findAllByUsername(username);
    }
}
