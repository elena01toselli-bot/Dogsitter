package com.progettodogsitting.dogsitting_backend.service;

import com.progettodogsitting.dogsitting_backend.DTO.UtenteDTO;
import com.progettodogsitting.dogsitting_backend.model.Cliente;
import com.progettodogsitting.dogsitting_backend.model.Dogsitter;
import com.progettodogsitting.dogsitting_backend.model.Utente;
import com.progettodogsitting.dogsitting_backend.repository.UtenteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

// Gestione della logica di business principale degli Utenti
@Service
public class UtenteService {
    

    // Collegamento col database 
    @Autowired
    private UtenteRepository repository;
    @Autowired
    private ClienteService clienteService;
    @Autowired
    private DogsitterService dogsitterService;

    // Ritorna la lista completa
    public List<Utente> findAll() {
        return repository.findAll();
    }

    // Cerca un utente in base alla chiave primaria
    public Optional<Utente> findById(String username) {
        return repository.findById(username);
    }

    // Inserisce o modifica utente
    public Utente save(Utente utente) {

        // controlla se l'utente esiste di che tipo è (cliente o dogsitter) e salva
        // nel database tutte le informazioni necessarie per l'utente

        if(utente.getRuolo().equalsIgnoreCase("cliente")) {
            Cliente cliente = (Cliente) utente;
            return clienteService.save(cliente);
        } else if (utente.getRuolo().equalsIgnoreCase("dogsitter")) {
            Dogsitter dogsitter = (Dogsitter) utente;
            return dogsitterService.save(dogsitter);
        }
        else{
            // Se il ruolo non è riconosciuto ritorna null 
            return null;

        }

    }

    // Cancella l'utente specificato
    public void deleteById(String username) {
        repository.deleteById(username);
    }

    // Verifica le credenziali per autorizzare l'accesso
    public String login(String username, String password) {
        // Cerca la combinazione username-password
        Optional<Utente> utente = repository.findByUsernameAndPassword(username, password);
        
        if (utente.isPresent()) {
            return utente.get().getUsername();
        }
        return null; // Login fallito
    }


    // Cerca utente come stringa semplice, a volte usato per validazioni
    public Optional<UtenteDTO> findByUsername(String username) {
        
        Optional<Utente> utente = repository.findByUsername(username);

        // Se l'utente esiste, mappa i dati essenziali in un DTO senza la password
        if (utente.isPresent()) {
            Utente u = utente.get();
            UtenteDTO dto = new UtenteDTO();
            dto.setUsername(u.getUsername());
            dto.setNomeBattesimo(u.getNomeBattesimo());
            dto.setCognome(u.getCognome());
            dto.setCap(u.getCap());
            dto.setNCivico(u.getNCivico());
            dto.setProvincia(u.getProvincia());
            dto.setVia(u.getVia());
            dto.setNTel(u.getNTel());

            // Non includiamo la password per motivi di sicurezza
            return Optional.of(dto);
        }

        return Optional.empty(); // Utente non trovato
    }

    // Determina il ruolo specifico dell'utente grazie all'ereditarietà di JPA (istanza)
    public String getRuolo(String username) {
        Optional<Utente> utente = repository.findById(username);
        if (utente.isPresent()) {
            Utente u = utente.get();
            // Controlla il tipo della classe istanziata
            if (u instanceof Cliente) {
                return "cliente";
            } else if (u instanceof Dogsitter) {
                return "dogsitter";
            }
        }
        // Valore di default se l'utente è un genitore puro senza sottoclasse o non trovato
        return "ruolo sconosciuto";
    }
}
