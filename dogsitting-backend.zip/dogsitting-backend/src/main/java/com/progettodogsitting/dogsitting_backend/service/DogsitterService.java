package com.progettodogsitting.dogsitting_backend.service;

import com.progettodogsitting.dogsitting_backend.model.Dogsitter;
import com.progettodogsitting.dogsitting_backend.repository.DogsitterRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

// Classe di servizio con la logica per i Dogsitter
@Service
public class DogsitterService {

    // Repository iniettato
    @Autowired
    private DogsitterRepository repository;

    // Trova tutti i dogsitter
    public List<Dogsitter> findAll() {
        return repository.findAll();
    }

    // Trova un singolo dogsitter in base allo username
    public Optional<Dogsitter> findById(String username) {
        return repository.findById(username);
    }

    // Registra o aggiorna un dogsitter
    public Dogsitter save(Dogsitter dogsitter) {
        return repository.save(dogsitter);
    }

    // Cancella il dogsitter tramite username
    public void deleteById(String username) {
        repository.deleteById(username);
    }
}
