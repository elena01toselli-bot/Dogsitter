package com.progettodogsitting.dogsitting_backend.repository;

import com.progettodogsitting.dogsitting_backend.model.Lezione1;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

// Repository per le operazioni CRUD sulla tabella LEZIONE_1
@Repository
public interface Lezione1Repository extends JpaRepository<Lezione1, String> {
}
