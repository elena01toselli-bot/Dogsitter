package com.progettodogsitting.dogsitting_backend.DTO;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalTime;

import lombok.Data;

@Data
public class LezioneDTO {
    
    // PK composta da nomeCampo, ora e data
    private String nomeCampo;
    private LocalTime ora;
    private LocalDate data;

    //altri attributi della lezione che il frontend si aspetta
    private String tipologia; // ad esempio "agility", "tartufo", ecc.
    private BigDecimal costo; // costo della lezione
    private Integer maxPartecipanti; // numero massimo di partecipanti alla lezione
    
}
