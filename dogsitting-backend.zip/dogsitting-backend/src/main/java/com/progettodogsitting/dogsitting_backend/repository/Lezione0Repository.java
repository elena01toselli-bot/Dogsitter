package com.progettodogsitting.dogsitting_backend.repository;

import com.progettodogsitting.dogsitting_backend.model.Lezione0;
import com.progettodogsitting.dogsitting_backend.model.Lezione0Id;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

// Repository per le operazioni CRUD sulla tabella LEZIONE_0
@Repository
public interface Lezione0Repository extends JpaRepository<Lezione0, Lezione0Id> {
    // Trova tutte le lezioni di un determinato campo
    List<Lezione0> findByIdNomeCampo(String nomeCampo);
}
