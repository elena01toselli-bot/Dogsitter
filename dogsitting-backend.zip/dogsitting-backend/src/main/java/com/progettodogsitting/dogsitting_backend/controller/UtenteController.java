package com.progettodogsitting.dogsitting_backend.controller;

import com.progettodogsitting.dogsitting_backend.config.JwtFilter;
import com.progettodogsitting.dogsitting_backend.model.Utente;
import com.progettodogsitting.dogsitting_backend.service.UtenteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.Map;

// Controller REST per la gestione generale degli Utenti e l'autenticazione
@RestController
@RequestMapping("/api/utenti")
@CrossOrigin(origins = "*")
public class UtenteController {

    // Servizio applicativo per Utente
    @Autowired
    private UtenteService service;

    // Filtro JWT per generare token di sessione sicuri
    @Autowired
    private JwtFilter jwtFilter;

    // Endpoint per l'accesso e generazione token (login)
    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody Map<String, String> body) {
        // Valida le credenziali tramite il servizio
        String username = service.login(body.get("username"), body.get("password"));

        // Se le credenziali sono corrette
        if (username != null) {
            // Genera il token JWT associato a questo username
            String token = jwtFilter.generaToken(username);
            // Restituisce il token e i dati essenziali dell'utente
            return ResponseEntity.ok(Map.of(
                "token", token,
                "user",  username
            ));
        }
        // Se le credenziali sono errate, restituisce errore 401
        return ResponseEntity.status(401).body(Map.of("error", "Credenziali errate"));
    }

    // Endpoint per la registrazione di un nuovo utente generico
    @PostMapping("/create")
    public Utente create(@RequestBody Utente utente) {

        // Salva e ritorna i dati

        if(service.save(utente)==null){
            // Se il ruolo non è riconosciuto ritorna null 
            return null;
        }
        else{
            return service.save(utente);
        }

    }
}