package com.progettodogsitting.dogsitting_backend.model;

import jakarta.persistence.*;
import lombok.Data;

// Entità che mappa la tabella ponte "offre" tra dogsitter e servizio
@Data
@Entity
@Table(name = "offre")
public class ServizioOfferto {

    // Chiave primaria composta (username_d, id_servizio)
    @EmbeddedId
    private OffreId id;

    // Collegamento in sola lettura alla tabella dogsitter
    @ManyToOne
    @MapsId("usernameDogsitter") // Associa questa relazione alla proprietà dell'ID composto
    @JoinColumn(name = "username_d")
    private Dogsitter dogsitter;

    // Collegamento in sola lettura alla tabella servizio
    @ManyToOne
    @MapsId("idServizio") // Associa questa relazione alla proprietà dell'ID composto
    @JoinColumn(name = "id_servizio")
    private Servizio servizio;

    // Prezzo fissato dal dogsitter per questo servizio
    @Column(name = "prezzo_listino")
    private Double prezzoListino;
}
