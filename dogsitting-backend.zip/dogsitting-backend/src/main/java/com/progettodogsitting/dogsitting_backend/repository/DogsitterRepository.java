package com.progettodogsitting.dogsitting_backend.repository;

import com.progettodogsitting.dogsitting_backend.model.Dogsitter;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

// Interfaccia per il mapping sulla tabella DOG_SITTER
@Repository
public interface DogsitterRepository extends JpaRepository<Dogsitter, String> {
    // I metodi CRUD base sono tutti forniti dall'estensione di JpaRepository
}
