package com.progettodogsitting.dogsitting_backend.controller;

import com.progettodogsitting.dogsitting_backend.model.Lezione1;
import com.progettodogsitting.dogsitting_backend.service.Lezione1Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

// Controller REST per la gestione delle tipologie di lezioni associate ai campi (LEZIONE_1)
@RestController
@RequestMapping("/api/lezione1")
@CrossOrigin(origins = "*")
public class Lezione1Controller {

    // Iniezione automatica del servizio Spring
    @Autowired
    private Lezione1Service service;

    // Ritorna tutte le entry configurate
    @GetMapping
    public List<Lezione1> getAll() {
        return service.findAll();
    }

    // Ritorna le impostazioni relative a un determinato campo, identificato dalla PK nomeCampo
    @GetMapping("/{nomeCampo}")
    public ResponseEntity<Lezione1> getById(@PathVariable String nomeCampo) {
        Optional<Lezione1> lezione = service.findById(nomeCampo);
        return lezione.map(ResponseEntity::ok)
                      .orElseGet(() -> ResponseEntity.notFound().build());
    }

    // Crea un nuovo record di tipologia lezione per un campo
    @PostMapping
    public Lezione1 create(@RequestBody Lezione1 lezione) {
        return service.save(lezione);
    }

    // Aggiorna un record esistente tramite nomeCampo
    @PutMapping("/{nomeCampo}")
    public ResponseEntity<Lezione1> update(@PathVariable String nomeCampo,
                                           @RequestBody Lezione1 lezione) {
        if (!service.findById(nomeCampo).isPresent()) {
            return ResponseEntity.notFound().build();
        }
        lezione.setNomeCampo(nomeCampo);
        return ResponseEntity.ok(service.save(lezione));
    }

    // Rimuove la configurazione associata a un campo
    @DeleteMapping("/{nomeCampo}")
    public ResponseEntity<Void> delete(@PathVariable String nomeCampo) {
        if (!service.findById(nomeCampo).isPresent()) {
            return ResponseEntity.notFound().build();
        }
        service.deleteById(nomeCampo);
        return ResponseEntity.noContent().build();
    }
}
