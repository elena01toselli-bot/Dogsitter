package com.progettodogsitting.dogsitting_backend.model;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

// Classe che rappresenta la chiave composta di Lezione0
// Implementa Serializable come richiesto da JPA per le chiavi composte
@Data
@NoArgsConstructor
@AllArgsConstructor
@Embeddable
public class Lezione0Id implements Serializable {

    // Riferimento al nome del campo, mappato sulla colonna nome_campo
    @Column(name = "nome_campo")
    private String nomeCampo;

    // Riferimento all'ora della lezione
    @Column(name = "ora")
    private String ora;

    // Riferimento alla data della lezione
    @Column(name = "data")
    private String data;
}
