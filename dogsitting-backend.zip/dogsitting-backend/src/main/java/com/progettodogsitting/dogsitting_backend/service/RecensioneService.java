package com.progettodogsitting.dogsitting_backend.service;

import com.progettodogsitting.dogsitting_backend.model.Recensione;
import com.progettodogsitting.dogsitting_backend.model.RecensioneId;
import com.progettodogsitting.dogsitting_backend.repository.RecensioneRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

// Servizio con la business logic delle recensioni
@Service
public class RecensioneService {

    // Il repository per le operazioni su database
    @Autowired
    private RecensioneRepository repository;

    // Ritorna le recensioni relative a un dato dogsitter
    public List<Recensione> findByDogsitter(String usernameDogsitter) {
        return repository.findByIdUsernameDogsitter(usernameDogsitter);
    }

    // Ritorna le recensioni scritte da un determinato cliente
    public List<Recensione> findByCliente(String usernameCliente) {
        return repository.findByIdUsernameCliente(usernameCliente);
    }

    // Inserisce o aggiorna una recensione
    public Recensione save(Recensione recensione) {
        return repository.save(recensione);
    }

    // Elimina una specifica recensione identificata dal suo ID composto
    public void deleteById(RecensioneId id) {
        repository.deleteById(id);
    }

    // Elimina fisicamente tutte le recensioni collegate a un utente cliente
    @Transactional
    public void deleteAllByCliente(String usernameCliente) {
        repository.deleteByIdUsernameCliente(usernameCliente);
    }

    // Trova tutti gli ID di dogsitter che hanno ricevuto recensioni
    public List<String> findDogsitterDisponibili() {
        return repository.findDistinctIdUsernameDogsitterBy();
    }
}
