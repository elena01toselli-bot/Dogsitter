package com.progettodogsitting.dogsitting_backend.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.progettodogsitting.dogsitting_backend.model.Cane;
import com.progettodogsitting.dogsitting_backend.service.CaneService;

// Controller REST per la gestione dei cani
@RestController
@RequestMapping("/api/cani")
@CrossOrigin(origins = "*")
public class CaneController {

    // Servizio per interagire con il database
    @Autowired
    private CaneService service;

    // Endpoint per recuperare tutti i cani di un determinato cliente
    @GetMapping("/cliente/{usernameCliente}")
    public List<Cane> getByCliente(@PathVariable String usernameCliente) {
        // Cerca e restituisce la lista di cani
        return service.findByCliente(usernameCliente);
    }

    // Endpoint per la creazione di un nuovo profilo cane
    @PostMapping
    public Cane create(@RequestBody Cane cane) {
        // Salva il record
        return service.save(cane);
    }

    // Endpoint per aggiornare un cane esistente
    @PutMapping("/{nMicrochip}")
    public ResponseEntity<Cane> update(@PathVariable String nMicrochip,
                                       @RequestBody Cane cane) {
        // Controlla l'esistenza del cane prima dell'aggiornamento
        if (!service.findById(nMicrochip).isPresent()) {
            return ResponseEntity.notFound().build();
        }
        // Imposta la chiave primaria nel corpo della richiesta
        cane.setNMicrochip(nMicrochip);
        // Salva e ritorna i dati
        return ResponseEntity.ok(service.save(cane));
    }

    // Endpoint per la rimozione di un cane
    @DeleteMapping("/{nMicrochip}")
    public ResponseEntity<Void> delete(@PathVariable String nMicrochip) {
        // Controlla se il cane esiste
        if (!service.findById(nMicrochip).isPresent()) {
            return ResponseEntity.notFound().build();
        }
        // Procede all'eliminazione fisica
        service.deleteById(nMicrochip);
        return ResponseEntity.noContent().build();
    }
}
