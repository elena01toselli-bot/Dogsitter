package com.progettodogsitting.dogsitting_backend.controller;

import com.progettodogsitting.dogsitting_backend.model.Lezione0;
import com.progettodogsitting.dogsitting_backend.model.Lezione0Id;
import com.progettodogsitting.dogsitting_backend.service.Lezione0Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

// Controller REST per la gestione delle lezioni (LEZIONE_0)
// Ho mantenuto l'endpoint /api/lezioni per compatibilità con il frontend
@RestController
@RequestMapping("/api/lezioni")
@CrossOrigin(origins = "*")
public class Lezione0Controller {

    // Iniezione del servizio per la logica di business
    @Autowired
    private Lezione0Service service;

    // Endpoint per ottenere le lezioni associate a un campo specifico
    @GetMapping("/campo/{nomeCampo}")
    public List<Lezione0> getByCampo(@PathVariable String nomeCampo) {
        return service.findByCampo(nomeCampo);
    }

    // Endpoint per creare una nuova lezione
    @PostMapping
    public Lezione0 create(@RequestBody Lezione0 lezione) {
        return service.save(lezione);
    }

    // Endpoint per aggiornare una lezione esistente
    @PutMapping
    public ResponseEntity<Lezione0> update(@RequestBody Lezione0 lezione) {
        // Verifica preliminare sulla presenza dei campi necessari nell'oggetto JSON
        if (lezione.getCampo() == null || lezione.getCampo().getNome() == null) {
            return ResponseEntity.badRequest().build();
        }
        // Controllo se la lezione da aggiornare esiste già per quel campo
        if (!service.findByCampo(lezione.getCampo().getNome()).contains(lezione)) {
            return ResponseEntity.notFound().build();
        }
        // Effettua l'aggiornamento
        return ResponseEntity.ok(service.save(lezione));
    }

    // Endpoint per cancellare una lezione fornendo in query string i 3 parametri della chiave
    @DeleteMapping
    public ResponseEntity<Void> delete(@RequestParam String nomeCampo,
                                       @RequestParam String ora,
                                       @RequestParam String data) {

        // Ricostruiamo la PK composta per avviare la ricerca
        Lezione0Id id = new Lezione0Id(nomeCampo, ora, data);
        
        // Cerchiamo la lezione nel database tramite il service
        Optional<Lezione0> lezione = service.findById(id);
        
        // Se non viene trovata, ritorna codice 404 (Not Found)
        if (lezione.isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        
        // Esegue la rimozione fisica se l'entità è presente
        service.deleteById(id);
        
        // Ritorna codice 204 (No Content) per confermare la cancellazione
        return ResponseEntity.noContent().build();
    }
}
