package com.progettodogsitting.dogsitting_backend.controller;

import com.progettodogsitting.dogsitting_backend.model.Prenotazione;
import com.progettodogsitting.dogsitting_backend.service.PrenotazioneService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Optional;

// Controller REST per la gestione delle prenotazioni (sia lezioni che dogsitting)
@RestController
@RequestMapping("/api/prenotazioni")
@CrossOrigin(origins = "*")
public class PrenotazioneController {

    // Servizio che racchiude la logica applicativa
    @Autowired
    private PrenotazioneService service;

    // Ritorna l'elenco delle prenotazioni relative a un determinato cliente
    @GetMapping("/cliente/{usernameCliente}")
    public List<Prenotazione> getByCliente(@PathVariable String usernameCliente) {

        // devi prendere tutte le prenozioni sia dog sitter sia lezioni 
        // quindi devi fare 2 chiamate al repository e unire i risultati in un'unica lista da restituire al frontend
        return service.findByCliente(usernameCliente);
    }

    // Ritorna l'elenco delle prenotazioni per un determinato dogsitter
    @GetMapping("/dogsitter/{usernameDogsitter}")
    public List<Prenotazione> getByDogsitter(@PathVariable String usernameDogsitter) {
        return service.findByDogsitter(usernameDogsitter);
    }

    // Cerca una prenotazione in base al suo codice identificativo
    @GetMapping("/{id}")
    public ResponseEntity<Prenotazione> getById(@PathVariable String id) {
        // Cerca nel db
        Optional<Prenotazione> pren = service.findByCodiceId(id);
        // Risponde con 200 OK se esiste
        return pren.map(ResponseEntity::ok)
                   .orElseGet(() -> ResponseEntity.notFound().build());
    }

    // Crea una nuova prenotazione
    @PostMapping
    public Prenotazione create(@RequestBody Prenotazione prenotazione) {

        // Genera un codice ID univoco per la prenotazione nel service 
        // dividi i casi in cui è una prenotazione di dog sitting o di lezione sempre nel service 
        // se è dogsitter allora messaggio:
        //usernameCliente: this.session.getUsername() ?? '',
        // usernameDogsitter
        // prezzoPattuito
        // idServizio
        // categoriaPrenotazione: 'dogsitter',
        // dataSvolgimento
        // oraSvolgimento
        // nMicrochip
        // codiceId


        //se invece è lezione allora messaggio:
        //   usernameCliente: this.session.getUsername() ?? '',
        //   nomeCampo:       this.campo?.nome ?? '',
        //   dataSvolgimento: this.giornoSelezionato?.data.toISOString().split('T')[0] ?? '', // "YYYY-MM-DD"
        //   oraSvolgimento:  this.prenotazione.orario,
        //   nMicrochip:      this.prenotazione.nMicrochipCane,
        //   categoriaPrenotazione: 'lezione',
        //   prezzoPattuito:  this.lezioneSelezionata?.costo ?? 0,
        //   codiceId:        0, // il backend assegna l'ID, qui mettiamo 0 o un valore fittizio



        // Salva e ritorna i dati generati
        return service.save(prenotazione);
    }

    // Aggiorna i dati di una prenotazione esistente
    @PutMapping("/{id}")
    public ResponseEntity<Prenotazione> update(@PathVariable String id,
                                               @RequestBody Prenotazione prenotazione) {
        // Verifica esistenza
        if (!service.findByCodiceId(id).isPresent()) {
            return ResponseEntity.notFound().build();
        }
        // Imposta l'ID per sicurezza prima del salvataggio
        prenotazione.setCodiceId(id);
        return ResponseEntity.ok(service.save(prenotazione));
    }

    // Rimuove una prenotazione specifica dal database
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable String id) {
        // Verifica esistenza
        if (!service.findByCodiceId(id).isPresent()) {
            return ResponseEntity.notFound().build();
        }
        // Cancella la prenotazione
        service.deleteByCodiceId(id);
        return ResponseEntity.noContent().build();
    }
}
