package com.progettodogsitting.dogsitting_backend.model;

import jakarta.persistence.*;
import lombok.Data;

// Entità che mappa la tabella "recensisce"
@Data
@Entity
@Table(name = "recensisce")
public class Recensione {

    // Chiave primaria composta (username_c, username_d)
    @EmbeddedId
    private RecensioneId id;

    // Relazione verso Cliente
    @ManyToOne
    @MapsId("usernameCliente") // Mappa sulla proprietà di RecensioneId
    @JoinColumn(name = "username_c")
    private Cliente cliente;

    // Relazione verso Dogsitter
    @ManyToOne
    @MapsId("usernameDogsitter") // Mappa sulla proprietà di RecensioneId
    @JoinColumn(name = "username_d")
    private Dogsitter dogsitter;

    // Voto dato dal cliente
    @Column(name = "voto", nullable = false)
    private Integer voto;

    // Commento di testo libero
    @Column(name = "commento")
    private String commento;

    // Data in cui è stata lasciata la recensione
    @Column(name = "data", nullable = false)
    private String data;
}
