package com.progettodogsitting.dogsitting_backend.service;

import com.progettodogsitting.dogsitting_backend.model.Cliente;
import com.progettodogsitting.dogsitting_backend.repository.ClienteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

// Classe di servizio che gestisce i Clienti
@Service
public class ClienteService {

    // Inietta l'accesso ai dati del cliente
    @Autowired
    private ClienteRepository repository;

    // Recupera la lista totale dei clienti
    public List<Cliente> findAll() {
        return repository.findAll();
    }

    // Recupera un cliente specifico usando l'username come PK
    public Optional<Cliente> findById(String username) {
        return repository.findById(username);
    }

    // Aggiunge o aggiorna le informazioni del cliente nel DB
    public Cliente save(Cliente cliente) {
        return repository.save(cliente);
    }

    // Cancella il profilo di un cliente dal database
    public void deleteById(String username) {
        repository.deleteById(username);
    }
}
